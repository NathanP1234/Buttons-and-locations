function text() {
    alert("I sell two whole products! A cool hat and a racecar bed")
}