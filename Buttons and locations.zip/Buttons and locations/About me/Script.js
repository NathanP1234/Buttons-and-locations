function picture() {
    document.getElementById('image')
            .style.display = "block";
}

function color() {
    document.getElementById('text')
    .style.color = "blue";
}