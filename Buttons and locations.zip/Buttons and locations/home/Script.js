function color() {
    document.getElementById('1')
    .style.color = "orange";
    document.body.style.background = "green";
}

function text() {
    document.getElementById('text')
    .style.display = "block";
}

function hide() {
    document.getElementById('text')
    .style.display = "none";
}