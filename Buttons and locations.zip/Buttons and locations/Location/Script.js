function show() {
    document.getElementById('image')
    .style.display = "block";
    document.getElementById('one')
    .style.display = "block";
}

function where() {
    document.getElementById('text')
    .style.display = "block";
    document.getElementById('two')
    .style.display = "block";
}

function really() {
    alert("I am certain")
    document.getElementById('zero')
    .style.display = "none";
    document.getElementById('one')
    .style.display = "none";
    document.getElementById('two')
    .style.display = "none";
    document.getElementById('image')
    .style.display = "none";
    document.getElementById('text')
    .style.display = "none";
    document.getElementById('bar')
    .style.display = "none";
}